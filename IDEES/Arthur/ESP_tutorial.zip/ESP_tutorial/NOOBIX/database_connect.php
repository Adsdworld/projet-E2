<?php
$con=mysqli_connect("localhost","id10222032_noob1","12345678","id10222032_esp8266");// server, user, password, database
?>