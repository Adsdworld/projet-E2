<?php
$con=mysqli_connect("localhost","id21292157_projete2user","projet-E2-password","id21292157_projete2database");// server, user, password, database
?>